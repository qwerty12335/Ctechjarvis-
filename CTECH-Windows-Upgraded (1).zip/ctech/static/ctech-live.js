// CTECH live mode: connects the HUD to the local backend (Agnes brain + Deepgram voice + Mac control).
(async () => {
  let health;
  try { const hr = await fetch("/api/health"); if (!hr.ok || !(hr.headers.get("content-type")||"").includes("json")) return; health = await hr.json(); } catch { return; }
  if (!health || health.ok !== true) return; // no backend → stays in demo mode
  window.REAL = true;
  log(`Brain: ${health.agnes ? "Agnes online" : "add Agnes key"}`, !health.agnes); log(`Voice: ${health.deepgram ? "Deepgram online" : "add Deepgram key"}`, !health.deepgram);

  /* ---- real Mac stats ---- */
  async function pull() {
    try {
      const s = await (await fetch("/api/stats")).json(); if (typeof s.cpu !== "number") return;
      vit.cpu = s.cpu; vit.mem = s.mem; vit.dsk = s.disk; vit.net = Math.min(100, s.netMBs * 4); vit.gpu = Math.min(100, s.cpu * 0.8);
      gv.g1 = s.battery; gv.g2 = s.temp ?? 40;
      document.getElementById("host").textContent = (s.host || "MAC").toUpperCase().slice(0, 14);
      document.getElementById("netV").textContent = s.netMBs + " MB/s";
    } catch {}
  }
  pull(); setInterval(pull, 2000);

  /* ---- conversation ---- */
  const history = [];
  let audio = null;

  window.say = async function (text) {
    setState("SPEAKING"); speaking = 1;
    const el = add("j"); let i = 0;
    const iv = setInterval(() => { el.textContent = text.slice(0, ++i); msgs.scrollTop = msgs.scrollHeight; if (i >= text.length) clearInterval(iv); }, 18);
    const done = () => { speaking = 0; setState("STANDBY"); };
    if (!health.deepgram) return setTimeout(done, text.length * 20);
    try {
      const r = await fetch("/api/tts", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ text }) });
      if (!r.ok) throw new Error(await r.text());
      if (audio) audio.pause();
      audio = new Audio(URL.createObjectURL(await r.blob()));
      audio.onended = done; audio.onerror = done;
      await audio.play();
    } catch (e) { log("Voice output failed: " + e.message.slice(0, 60), 1); setTimeout(done, text.length * 20); }
  };

  window.handle = async function (q) {
    if (!q.trim()) return;
    add("u").textContent = q; setState("THINKING"); log("Command: " + q);
    history.push({ role: "user", content: q });
    try {
      const r = await fetch("/api/chat", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ history }) });
      const j = await r.json();
      if (!r.ok) throw new Error(j.error || "error");
      (j.actions || []).forEach(a => log(`${a.ok ? "✓" : "✗"} ${a.tool} ${Object.values(a.args || {}).join(" ")}`, !a.ok));
      if (j.hud?.mode) setMode(j.hud.mode);
      history.push({ role: "assistant", content: j.reply });
      say(j.reply);
    } catch (e) {
      log("Brain error: " + e.message.slice(0, 80), 1);
      say("I'm having trouble reaching my brain, sir. Check the Agnes key in the .env file.");
    }
  };

  /* ---- voice input: click VOICE to talk, click again to send ---- */
  let rec = null, chunks = [];
  const mic = document.getElementById("mic");
  mic.onclick = async () => {
    if (rec && rec.state === "recording") { rec.stop(); return; }
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      chunks = []; rec = new MediaRecorder(stream);
      rec.ondataavailable = e => e.data.size && chunks.push(e.data);
      rec.onstop = async () => {
        stream.getTracks().forEach(t => t.stop());
        listening = false; mic.classList.remove("live"); setState("THINKING");
        const fd = new FormData(); fd.append("audio", new Blob(chunks, { type: rec.mimeType }), "voice.webm");
        try {
          const j = await (await fetch("/api/stt", { method: "POST", body: fd })).json();
          if (j.text) handle(j.text); else { log("Didn't catch that", 1); setState("STANDBY"); }
        } catch { log("Speech-to-text failed", 1); setState("STANDBY"); }
      };
      rec.start(); listening = true; mic.classList.add("live"); setState("LISTENING");
      setTimeout(() => rec && rec.state === "recording" && rec.stop(), 15000);
    } catch { log("Microphone permission denied", 1); }
  };
  // Space bar = push to talk when not typing
  document.addEventListener("keydown", e => { if (e.code === "Space" && document.activeElement.tagName !== "INPUT" && !e.repeat) { e.preventDefault(); mic.click(); } });
  document.addEventListener("keyup", e => { if (e.code === "Space" && document.activeElement.tagName !== "INPUT" && rec?.state === "recording") rec.stop(); });

  document.getElementById("q").placeholder = "Type a command, or hold SPACE to talk, sir…";

  /* ---- vision: paste a screenshot, or drag-and-drop an image/video onto the chat ---- */
  async function showVision(label, promise) {
    add("u").textContent = label; setState("THINKING"); log(label);
    try {
      const r = await promise;
      const j = await r.json();
      if (!r.ok) throw new Error(j.error || "vision error");
      const text = j.description || j.summary || j.reply || (j.timeline ? j.timeline.map(t => `[${t.timestamp.toFixed(1)}s] ${t.description}`).join(" ") + "\n\n" + j.summary : "No description returned.");
      say(text);
    } catch (e) {
      log("Vision failed: " + e.message.slice(0, 80), 1);
      say("I couldn't make sense of that image, sir: " + e.message.slice(0, 120));
    }
  }

  function analyzeImageFile(file, question) {
    const fd = new FormData(); fd.append("image", file); if (question) fd.append("question", question);
    return showVision("[image] " + (question || "what am I looking at?"), fetch("/api/vision", { method: "POST", body: fd }));
  }
  function analyzeVideoFile(file, question) {
    const fd = new FormData(); fd.append("video", file); if (question) fd.append("question", question);
    return showVision("[video] " + (question || "what happens in this clip?"), fetch("/api/video-analyze", { method: "POST", body: fd }));
  }
  window.ctechAnalyzeScreen = (question) => showVision("[screen] " + (question || "what am I looking at?"),
    fetch("/api/vision", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ question }) }));

  document.addEventListener("paste", (e) => {
    const item = [...(e.clipboardData?.items || [])].find(i => i.type.startsWith("image/"));
    if (item) analyzeImageFile(item.getAsFile(), document.getElementById("q").value || "");
  });
  const dropZone = document.querySelector(".chat") || document.body;
  ["dragover", "dragenter"].forEach(ev => dropZone.addEventListener(ev, e => e.preventDefault()));
  dropZone.addEventListener("drop", (e) => {
    const file = e.dataTransfer?.files?.[0];
    if (!file) return;
    e.preventDefault();
    const q = document.getElementById("q").value || "";
    if (file.type.startsWith("image/")) analyzeImageFile(file, q);
    else if (file.type.startsWith("video/")) analyzeVideoFile(file, q);
  });
})();
