@echo off
REM Double-click this file on Windows to launch CTECH.
cd /d "%~dp0"
where node >nul 2>nul
if %errorlevel% neq 0 (
  echo Node.js is not installed. Get it from https://nodejs.org ^(LTS^) and run this again.
  pause
  exit /b 1
)
if not exist node_modules (
  call npm install
)
call npm start
pause
