# C.T.E.C.H. — your personal JARVIS

HUD interface + Agnes AI brain + Deepgram voice + real OS control. Runs on **Windows** and **macOS** —
every OS-touching tool goes through `lib/os/win.js` or `lib/os/mac.js` automatically, picked at
startup by `lib/os/index.js` based on `process.platform`. (This started life as a Mac-only build;
it's now cross-platform — see "Windows vs macOS" below for what differs.)

## Setup (one time, a few minutes)
1. Install **Node.js LTS** from https://nodejs.org
2. The supplied `.env` is configured for Agnes AI and Deepgram. Keep it private and never commit it to Git. If you need to configure another machine, copy `.env.example` to `.env` and add your own keys:
   ```
   AGNES_API_KEY=sk-....
   DEEPGRAM_API_KEY=....
   ```
3. From the project folder, run once: `npm install`
4. For real browser automation (`browser_*` tools): `npx playwright install chromium` (one-time download, ~150–300MB).
5. For video analysis (drag a video onto the chat): install **ffmpeg** and make sure it's on PATH.
   - Windows: `winget install ffmpeg` (or download a build and add its `bin` folder to PATH)
   - macOS: `brew install ffmpeg`
6. Launch it:
   - **Windows**: double-click **start.bat**
   - **macOS**: double-click **start.command** (first time: right-click → Open)
   - CTECH opens at http://localhost:5454

CTECH is a **local app** — it needs real OS-level access (PowerShell/.NET on Windows, AppleScript/`screencapture` on macOS, your filesystem either way) that a serverless host like Vercel cannot provide, so it isn't deployed there and shouldn't be; keep running it locally via `start.bat`/`start.command` or `npm start`.

## How to use
- Type a command, or **hold SPACE** (or click VOICE) to talk.
- Allow microphone access in the browser the first time.
- **Windows**: the first time CTECH runs a PowerShell-based tool (volume, screenshot, dark mode, etc.) Windows may show a brief console flash or a SmartScreen/firewall prompt — allow it. No separate Accessibility permission step like macOS.
- **macOS**: the first time CTECH controls an app, macOS will ask for permission (Automation / Accessibility). Click OK.

## What CTECH can do right now
| Say… | What happens |
|---|---|
| "Open Spotify" / "Quit Spotify" | Opens or quits any app (`Start-Process`/`Stop-Process` on Windows, `open`/AppleScript on macOS) |
| "Search for the best Lagos restaurants" | Google search in your browser |
| "Play Burna Boy on YouTube" | YouTube search |
| "Pause the music" / "Next track" | Windows: system media keys (follows whichever player has focus — Spotify, browser, etc). macOS: Apple Music control. |
| "Set volume to 30" | System volume — exact 0–100% on both platforms (Windows via the Core Audio COM interface, not a key-mashing guess) |
| "Switch to dark mode" | OS appearance toggle |
| "Remind me to call mum" | macOS: real Reminders app. Windows: appended to local `reminders.txt` (no native Reminders app to hook into) |
| "Make a note called Ideas…" | macOS: real Notes app. Windows: appended to local `notes.txt` |
| "Run my Good Morning shortcut" | macOS Shortcuts only — reports "not supported" on Windows, no fake equivalent |
| "Take a screenshot" | Saved to Desktop (PowerShell+GDI on Windows, `screencapture` on macOS) |
| "What's on my clipboard?" | Reads clipboard |
| "System status" | Live CPU, RAM, disk, battery |
| "Remember I'm a software builder" | Long-term memory (`memory.json`, categorized, updates instead of duplicating) |
| "Forget that I'm a software builder" | Deletes matching memory |
| "Battle mode" | HUD turns red |
| "What am I looking at?" / "see_screen" | Captures your real screen and describes it via Agnes vision |
| "Annotate my screen" | Captures the screen and draws boxes around detected elements (saved as a temp PNG; path is read back in chat) |
| Paste or drag an image onto the chat | Sends it to `/api/vision` and reads back a real description |
| Drag a video onto the chat | Samples frames with ffmpeg and summarizes what happens, with timestamps |
| "Open google.com in your browser and read the page" | Runs in CTECH's own Playwright-driven Chromium (`browser_navigate`, `browser_click`, `browser_type`, `browser_scroll`, `browser_extract_text`, `browser_back`, `browser_new_tab`, `browser_switch_tab`) — separate from `open_url`, which just opens your normal system browser |
| "Research X and prepare a report" | `POST /api/task {"objective": "..."}` runs the same brain/tools for up to 25 steps and returns a step-by-step success/failure report instead of stopping after a few tool calls |
| Open `http://localhost:5454/vr.html` | Optional standalone WebXR/3D spatial mode — separate page, doesn't touch or change the main HUD |
| Open `http://localhost:5454/live.html` | **Live vision**: point your camera or share your screen and it draws real-time boxes around ~80 common object classes (person, phone, cup, laptop, book, etc.) using a local TensorFlow.js model — no lag, no API calls, keeps up with motion. Type anything else to find ("the error message", "my coffee mug") and click ASK AGNES for a one-off semantic pass drawn in a second color — that one takes a few seconds, same as the other vision tools |

## Windows vs macOS — what genuinely differs
There's no Windows equivalent for a few macOS-only concepts, so these are handled honestly rather than faked:
- **Reminders / Notes**: no native Windows app to target, so these write to plain `reminders.txt`/`notes.txt` in the project folder instead. CTECH will say so if asked.
- **Shortcuts**: macOS-only; `run_shortcut` reports "not supported on Windows."
- **Media keys**: on Windows, `music_control` sends the real system media-key events (play/pause/next/prev), which affects whatever app currently owns media focus — not a specific "Apple Music" app, since Windows has no single default music app.
- Everything else (open/quit apps, volume, dark mode, screenshots, clipboard, sleep display, vision, video, browser automation, memory, the agent loop) is a real, working implementation on both platforms — just via different system calls under the hood (`lib/os/win.js` vs `lib/os/mac.js`).

## What's real vs. what needs more setup
- Screen vision, image/video analysis and the agent loop are fully wired and run for real the moment `AGNES_API_KEY` is set — but they need an Agnes model that actually accepts image input. If `AGNES_MODEL` isn't vision-capable, vision calls return a clear error (never a made-up description); set `AGNES_VISION_MODEL` to a vision model if your main chat model isn't one.
- `browser_*` tools need `npx playwright install chromium` once. They drive a separate Chromium window CTECH controls directly — by design this can't reach tabs already open in your regular Chrome/Edge, since no website or background script is allowed to do that for security reasons; that's a browser-security limit, not something CTECH is missing.
- Video analysis needs `ffmpeg` on PATH.
- "Background operation" / staying available while you work other apps is whatever Node.js + your OS already give a long-running local process (it keeps running, survives you tabbing away) — there's no separate daemon, system-tray app, or push-notification layer here; that would be a real desktop-app rewrite, not a server.js change.
- VR mode is a genuinely separate, optional 3D page (`static/vr.html`) using WebXR; it renders as a normal 3D scene in any browser and goes immersive only on WebXR-capable hardware. It reuses the same `/api/chat` and `/api/tts` as the main HUD.
- Live vision (`static/live.html`) needs an internet connection the first time it runs, to download the TensorFlow.js/coco-ssd model from a CDN (a few MB, then cached by the browser). After that the real-time boxes run fully offline — no Agnes call, no lag. The "ASK AGNES" button is separate and does use the network/your API key each time you click it.

## Files
- `server.js` — the brain + tools (add new tools in the `tools` array); OS-specific work is delegated to `lib/os`, never done inline here
- `lib/os/index.js` — picks `mac.js` or `win.js` based on `process.platform`
- `lib/os/mac.js` — macOS implementation (AppleScript/`open`/`screencapture`/etc)
- `lib/os/win.js` — Windows implementation (PowerShell/.NET: `Start-Process`/`Stop-Process`, Core Audio COM for volume, GDI for screenshots, registry for dark mode, media-key events, `Get-Clipboard`)
- `lib/memory.js` — categorized long-term memory store (auto-migrates the old `memory.json` format)
- `lib/vision.js` — screen capture (via `lib/os`) + image analysis/annotation via Agnes's multimodal endpoint
- `lib/browser.js` — Playwright-backed browser automation (separate Chromium instance, OS-independent)
- `lib/video.js` — ffmpeg frame sampling + per-frame/holistic video analysis
- `deepgram.js` — Deepgram SDK client (the live server routes use Deepgram REST endpoints)
- `static/index.html` — the HUD (unchanged layout/theme)
- `static/ctech-live.js` — connects the HUD to the backend; now also handles pasted/dropped images & videos
- `static/vr.html` — optional standalone spatial/VR page
- `start.bat` — Windows launcher
- `start.command` — macOS launcher
- `.env` — local API credentials (private; excluded from Git)
- `.env.example` — safe environment-variable template
