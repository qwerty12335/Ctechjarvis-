#!/bin/bash
# Double-click this file on your Mac to launch CTECH.
cd "$(dirname "$0")"
if ! command -v node >/dev/null 2>&1; then
  echo "Node.js is not installed. Get it from https://nodejs.org (LTS) and run this again."; read -p "Press Enter to close"; exit 1
fi
[ -d node_modules ] || npm install
npm start
