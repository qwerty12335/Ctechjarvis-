// CTECH backend — runs locally on your computer.
// Brain: Agnes AI  ·  Voice: Deepgram  ·  Vision: Agnes multimodal  ·  Browser: Playwright
// Hands: lib/os/<platform>.js — macOS via AppleScript, Windows via PowerShell/.NET
require("dotenv").config();
const express = require("express");
const multer = require("multer");
const si = require("systeminformation");
const os = require("os");
const fs = require("fs");
const path = require("path");
const { execFile } = require("child_process");

const memory = require("./lib/memory");
const vision = require("./lib/vision");
const browserTool = require("./lib/browser");
const video = require("./lib/video");
const platform = require("./lib/os"); // picks mac.js / win.js for you automatically

const AGNES_KEY = process.env.AGNES_API_KEY;
const DG_KEY = process.env.DEEPGRAM_API_KEY;
const MODEL = process.env.AGNES_MODEL || "agnes-2.5-flash";
const VISION_MODEL = process.env.AGNES_VISION_MODEL || MODEL;
const VOICE = process.env.DEEPGRAM_VOICE || "aura-2-orion-en";
const PORT = process.env.PORT || 5454;
const AGNES_URL = "https://apihub.agnes-ai.com/v1/chat/completions";
const IS_MAC = process.platform === "darwin";

const app = express();
app.use(express.json({ limit: "2mb" }));
app.use(express.static(path.join(__dirname, "static")));
const upload = multer({ storage: multer.memoryStorage(), limits: { fileSize: 200 * 1024 * 1024 } });

// ---------- helpers ----------
// Plain shell runner, only still used for things that are the same on every OS (open_url via `open`
// doesn't exist on Windows, so that now goes through platform.openUrl instead — see tools below).
const run = (cmd, args) => new Promise((resolve) => {
  execFile(cmd, args, { timeout: 15000 }, (err, stdout, stderr) =>
    resolve(err ? { ok: false, out: (stderr || err.message).trim() } : { ok: true, out: (stdout || "done").trim() }));
});

// Actions that change system/app state in a way that's annoying or risky to undo.
// They still run (there's no confirmation UI in the HUD), but the agent is instructed
// to ask the user in plain conversation first, and every one is logged.
const DESTRUCTIVE = new Set(["quit_app", "sleep_display", "forget"]);

async function systemStatus() {
  const [load, mem, disks, batt, net, temp] = await Promise.all([
    si.currentLoad(), si.mem(), si.fsSize(), si.battery(), si.networkStats(), si.cpuTemperature().catch(() => ({}))
  ]);
  const disk = disks.find(d => d.mount === "/" || d.mount === "/System/Volumes/Data") || disks[0] || {};
  const n = net[0] || {};
  return {
    host: os.hostname().replace(/\.local$/, ""),
    cpu: Math.round(load.currentLoad || 0),
    mem: Math.round((mem.active / mem.total) * 100),
    disk: Math.round(disk.use || 0),
    battery: batt.hasBattery ? batt.percent : 100,
    charging: !!batt.isCharging,
    temp: temp.main ? Math.round(temp.main) : null,
    netMBs: +(((n.rx_sec || 0) + (n.tx_sec || 0)) / 1e6).toFixed(1),
  };
}

// Last screenshot path, so "what am I looking at" doesn't need a fresh capture every time
// if the user is iterating on the same screen within a few seconds.
let lastScreenshot = { path: null, at: 0 };
async function getScreenshot(fresh = false) {
  if (!fresh && lastScreenshot.path && Date.now() - lastScreenshot.at < 3000 && fs.existsSync(lastScreenshot.path)) {
    return lastScreenshot.path;
  }
  const p = await vision.captureScreen();
  lastScreenshot = { path: p, at: Date.now() };
  return p;
}

// ---------- tools CTECH can use ----------
// Every tool below that touches the OS (app/media/volume/appearance/reminders/notes/
// screenshot/clipboard/display) delegates to lib/os, which picks the macOS or Windows
// implementation for you. On platforms with no real equivalent, that layer returns
// { ok:false, out:"<thing> isn't supported on <platform>" } instead of pretending it worked.
const tools = [
  { name: "open_app", description: "Open an application by name, e.g. Spotify, Notes, Chrome.", params: { name: "string" },
    run: ({ name }) => platform.openApp(name) },
  { name: "quit_app", description: "Quit a running application by name. Ask the user to confirm in conversation before calling this.", params: { name: "string" },
    run: ({ name }) => platform.quitApp(name) },
  { name: "open_url", description: "Open a website URL in the user's default system browser (not CTECH's own automated browser).", params: { url: "string" },
    run: ({ url }) => platform.openUrl(/^https?:\/\//.test(url) ? url : "https://" + url) },
  { name: "web_search", description: "Search Google in the browser for the user.", params: { query: "string" },
    run: ({ query }) => platform.openUrl("https://www.google.com/search?q=" + encodeURIComponent(query)) },
  { name: "play_youtube", description: "Search and play something on YouTube.", params: { query: "string" },
    run: ({ query }) => platform.openUrl("https://www.youtube.com/results?search_query=" + encodeURIComponent(query)) },
  { name: "music_control", description: "Control whatever's playing (Apple Music on macOS; system media keys on Windows, so it follows whatever player has focus, e.g. Spotify): play, pause, next track, previous track.", params: { action: "play|pause|next track|previous track" },
    run: ({ action }) => platform.musicControl(action) },
  { name: "set_volume", description: "Set the system output volume from 0 to 100.", params: { level: "number" },
    run: ({ level }) => platform.setVolume(level) },
  { name: "toggle_dark_mode", description: "Switch the OS between dark and light appearance.", params: {},
    run: () => platform.toggleDarkMode() },
  { name: "create_reminder", description: "Save a reminder. Uses the real Reminders app on macOS; on Windows (no equivalent app) it's appended to a local reminders.txt instead — say so if asked.", params: { text: "string" },
    run: ({ text }) => platform.createReminder(text) },
  { name: "create_note", description: "Save a note. Uses the real Notes app on macOS; on Windows (no equivalent app) it's appended to a local notes.txt instead — say so if asked.", params: { title: "string", body: "string" },
    run: ({ title, body }) => platform.createNote(title, body) },
  { name: "run_shortcut", description: "Run one of the user's macOS Shortcuts by its exact name. Not available on Windows — there is no Shortcuts equivalent there.", params: { name: "string" },
    run: ({ name }) => platform.runShortcut(name) },
  { name: "take_screenshot", description: "Take a screenshot and save it to the Desktop.", params: {},
    run: () => platform.takeScreenshot() },
  { name: "read_clipboard", description: "Read the text currently on the clipboard.", params: {},
    run: () => platform.readClipboard() },
  { name: "sleep_display", description: "Turn the display off / sleep the screen. Ask the user to confirm first — this is disruptive.", params: {},
    run: () => platform.sleepDisplay() },
  { name: "system_status", description: "Get live CPU, memory, disk, battery, temperature and network stats.", params: {},
    run: async () => ({ ok: true, out: JSON.stringify(await systemStatus()) }) },

  // ---- memory ----
  { name: "remember", description: "Save a long-term fact about the user (name, preferences, projects). Updates an existing fact instead of duplicating when it recognizes the same subject.", params: { fact: "string" },
    run: ({ fact }) => memory.remember(fact) },
  { name: "recall", description: "Search long-term memory for facts matching a word or phrase.", params: { query: "string" },
    run: ({ query }) => { const r = memory.recall(query); return { ok: true, out: r.length ? r.map(f => f.fact).join("; ") : "nothing found" }; } },
  { name: "forget", description: "Delete long-term facts whose text matches the given phrase. Ask the user to confirm first.", params: { query: "string" },
    run: ({ query }) => memory.forget(query) },

  { name: "set_hud_mode", description: "Change the HUD color mode: diag (blue), flight (amber) or battle (red).", params: { mode: "diag|flight|battle" },
    run: ({ mode }) => ({ ok: true, out: "mode set", hud: { mode } }) },

  // ---- vision ----
  { name: "see_screen", description: "Capture the current screen and answer a question about what is actually visible on it right now (UI elements, text, errors, open apps).", params: { question: "string" },
    run: async ({ question }) => {
      try {
        const shot = await getScreenshot(true);
        const out = await vision.analyzeImage({ apiKey: AGNES_KEY, model: VISION_MODEL, imagePath: shot, question });
        return { ok: true, out };
      } catch (e) { return { ok: false, out: e.message }; }
    } },
  { name: "annotate_screen", description: "Capture the current screen, identify interactive elements (buttons, icons, text, errors) and draw boxes around them.", params: { question: "string" },
    run: async ({ question }) => {
      try {
        const shot = await getScreenshot(true);
        const r = await vision.analyzeAndAnnotate({ apiKey: AGNES_KEY, model: VISION_MODEL, imagePath: shot, question });
        return { ok: true, out: r.summary + (r.annotatedPath ? ` (annotated image: ${r.annotatedPath})` : r.note ? ` (${r.note})` : "") };
      } catch (e) { return { ok: false, out: e.message }; }
    } },

  // ---- browser automation (CTECH's own Chromium, via Playwright — distinct from open_url) ----
  { name: "browser_navigate", description: "Open a URL in CTECH's own automated browser, which CTECH can then read and click inside (separate from the system browser `open_url` opens).", params: { url: "string" },
    run: ({ url }) => browserTool.navigate(url).catch(e => ({ ok: false, out: e.message })) },
  { name: "browser_click", description: "Click an element in CTECH's automated browser by its visible text or a CSS selector.", params: { target: "string" },
    run: ({ target }) => browserTool.click(target).catch(e => ({ ok: false, out: e.message })) },
  { name: "browser_type", description: "Type text into a field in CTECH's automated browser. Leave target empty to type into whatever is focused.", params: { target: "string", text: "string" },
    run: ({ target, text }) => browserTool.type(target, text).catch(e => ({ ok: false, out: e.message })) },
  { name: "browser_scroll", description: "Scroll the page in CTECH's automated browser.", params: { direction: "up|down" },
    run: ({ direction }) => browserTool.scroll(direction).catch(e => ({ ok: false, out: e.message })) },
  { name: "browser_extract_text", description: "Read the visible text content of the current page in CTECH's automated browser.", params: {},
    run: () => browserTool.extractText().catch(e => ({ ok: false, out: e.message })) },
  { name: "browser_back", description: "Go back a page in CTECH's automated browser.", params: {},
    run: () => browserTool.goBack().catch(e => ({ ok: false, out: e.message })) },
  { name: "browser_new_tab", description: "Open a new tab in CTECH's automated browser.", params: {},
    run: () => browserTool.newTab().then(r => ({ ok: r.ok, out: r.out })).catch(e => ({ ok: false, out: e.message })) },
  { name: "browser_switch_tab", description: "Switch to another open tab in CTECH's automated browser (1-indexed).", params: { index: "number" },
    run: ({ index }) => browserTool.switchTab(Math.max(0, (+index || 1) - 1)).catch(e => ({ ok: false, out: e.message })) },
];
const toolSpecs = tools.map(t => ({
  type: "function",
  function: {
    name: t.name, description: t.description,
    parameters: { type: "object", properties: Object.fromEntries(Object.entries(t.params).map(([k, v]) =>
      [k, v === "number" ? { type: "number" } : v.includes("|") ? { type: "string", enum: v.split("|") } : { type: "string" }])),
      required: Object.keys(t.params) }
  }
}));

function systemPrompt() {
  const facts = memory.allFacts().map(m => "- " + m.fact).join("\n") || "- (nothing yet)";
  return `You are CTECH, a calm, witty, British-butler style AI assistant running locally on the user's ${IS_MAC ? "Mac" : "Windows PC"}, inspired by JARVIS.
Address the user as "sir". Keep spoken replies short (1-3 sentences) because they are read aloud.
Current local time: ${new Date().toString()}. Location: Lagos, Nigeria.

How to work:
- Decide first whether the user is asking a QUESTION (just answer) or asking you to DO something (use a tool).
- For anything multi-step ("research X and summarize", "find Y and open it"), break it into the smallest tool calls needed, run them one at a time, and look at each result before deciding the next step — don't guess ahead.
- Never claim you did something unless the matching tool result says ok. If a tool fails, say so plainly and suggest what the user could do instead — including when a tool says something simply isn't supported on this OS (e.g. Reminders/Notes/Shortcuts on Windows). Don't apologize for a missing tool as if it were a malfunction; just state the limitation and the fallback.
- Before quit_app, sleep_display, or forget, ask the user to confirm in plain conversation unless they already clearly asked for exactly that action.
- "see_screen"/"annotate_screen" are real screen captures — only describe what they actually return, never invent screen contents.
- browser_* tools control CTECH's own separate automated browser window, not the user's regular browser tabs — be clear about that distinction if it matters to what they asked.

What you remember about the user:
${facts}`;
}

async function agnes(messages) {
  if (!AGNES_KEY) throw new Error("Agnes is not configured. Set AGNES_API_KEY in .env.");
  const r = await fetch(AGNES_URL, {
    method: "POST",
    headers: { Authorization: `Bearer ${AGNES_KEY}`, "Content-Type": "application/json" },
    body: JSON.stringify({ model: MODEL, messages, tools: toolSpecs, tool_choice: "auto", temperature: 0.6 })
  });
  const j = await r.json().catch(() => ({}));
  if (!r.ok) throw new Error(`Agnes ${r.status}: ${j.error?.message || JSON.stringify(j).slice(0, 200)}`);
  return j.choices[0].message;
}

// Runs the full plan → tool → observe → verify loop. Shared by /api/chat (interactive,
// capped tighter) and /api/task (autonomous objectives, more rounds, structured report).
async function runAgentLoop(history, { maxRounds = 5 } = {}) {
  const messages = [{ role: "system", content: systemPrompt() }, ...history];
  const actions = []; let hud = null;
  for (let round = 0; round < maxRounds; round++) {
    const msg = await agnes(messages);
    messages.push(msg);
    if (!msg.tool_calls?.length) return { reply: msg.content || "Done, sir.", actions, hud, messages };
    for (const call of msg.tool_calls) {
      const tool = tools.find(t => t.name === call.function.name);
      let args = {}; try { args = JSON.parse(call.function.arguments || "{}"); } catch {}
      const result = tool ? await tool.run(args) : { ok: false, out: "unknown tool" };
      if (result.hud) hud = result.hud;
      actions.push({ tool: call.function.name, args, ok: result.ok, out: String(result.out).slice(0, 400), destructive: DESTRUCTIVE.has(call.function.name) });
      console.log("⚙", call.function.name, args, result.ok ? "OK" : "FAIL", String(result.out).slice(0, 120));
      messages.push({ role: "tool", tool_call_id: call.id, content: JSON.stringify({ ok: result.ok, out: result.out }) });
    }
  }
  return { reply: "I've done what I can within this step limit, sir — want me to continue?", actions, hud, messages };
}

// ---------- routes ----------
app.get("/api/health", (req, res) => res.json({
  ok: true,
  agnes: !!AGNES_KEY && !AGNES_KEY.startsWith("paste"),
  deepgram: !!DG_KEY && !DG_KEY.startsWith("paste"),
  mac: IS_MAC,
  platform: process.platform,
  model: MODEL,
  vision: !!AGNES_KEY,
  browser: browserTool.isAvailable(),
}));

app.get("/api/stats", async (req, res) => {
  try { res.json(await systemStatus()); } catch (e) { res.status(500).json({ error: e.message }); }
});

app.post("/api/chat", async (req, res) => {
  try {
    const history = (req.body.history || []).slice(-16);
    const { reply, actions, hud } = await runAgentLoop(history, { maxRounds: 5 });
    res.json({ reply, actions, hud });
  } catch (e) {
    console.error(e.message);
    res.status(500).json({ error: e.message });
  }
});

// Autonomous multi-step objective: "research X, compare, prepare a report" etc.
// Same brain and tools as /api/chat, just far more rounds and a structured summary
// of everything attempted, so a long task doesn't silently stop short.
app.post("/api/task", async (req, res) => {
  try {
    const objective = String(req.body.objective || "").trim();
    if (!objective) return res.status(400).json({ error: "objective is required" });
    const history = [{ role: "user", content: objective }];
    const { reply, actions, hud } = await runAgentLoop(history, { maxRounds: 25 });
    res.json({
      reply,
      actions,
      hud,
      report: {
        objective,
        steps: actions.length,
        succeeded: actions.filter(a => a.ok).length,
        failed: actions.filter(a => !a.ok).length,
      },
    });
  } catch (e) {
    console.error(e.message);
    res.status(500).json({ error: e.message });
  }
});

// Screen / image vision — upload an image, or omit the file to capture the live screen.
app.post("/api/vision", upload.single("image"), async (req, res) => {
  try {
    if (!AGNES_KEY) return res.status(503).json({ error: "Agnes is not configured. Set AGNES_API_KEY in .env." });
    const question = req.body.question || "Describe exactly what is visible in this image.";
    const annotate = req.body.annotate === "true";
    const opts = { apiKey: AGNES_KEY, model: VISION_MODEL, question };
    if (req.file) { opts.imageBuffer = req.file.buffer; opts.mime = req.file.mimetype; }
    else { opts.imagePath = await getScreenshot(true); }

    if (annotate) {
      const r = await vision.analyzeAndAnnotate(opts);
      return res.json({ summary: r.summary, elements: r.elements, note: r.note });
    }
    const out = await vision.analyzeImage(opts);
    res.json({ description: out });
  } catch (e) {
    console.error(e.message);
    res.status(500).json({ error: e.message });
  }
});

// Live view — the browser sends a frame (camera or shared screen) plus what to highlight,
// and gets back boxes in percent coordinates to draw over the moving video.
app.post("/api/vision-locate", upload.single("frame"), async (req, res) => {
  try {
    if (!AGNES_KEY) return res.status(503).json({ error: "Agnes is not configured. Set AGNES_API_KEY in .env." });
    if (!req.file) return res.status(400).json({ error: "A frame image is required." });
    const out = await vision.locateElements({
      apiKey: AGNES_KEY, model: VISION_MODEL,
      imageBuffer: req.file.buffer, mime: req.file.mimetype,
      query: String(req.body.query || "").slice(0, 300),
    });
    res.json(out);
  } catch (e) {
    console.error(e.message);
    res.status(500).json({ error: e.message });
  }
});

// Video intelligence — upload a video, get a real frame-sampled analysis.
app.post("/api/video-analyze", upload.single("video"), async (req, res) => {
  const tmp = req.file ? path.join(os.tmpdir(), `ctech-upload-${Date.now()}-${req.file.originalname}`) : null;
  try {
    if (!AGNES_KEY) return res.status(503).json({ error: "Agnes is not configured. Set AGNES_API_KEY in .env." });
    if (!req.file) return res.status(400).json({ error: "A video file is required." });
    fs.writeFileSync(tmp, req.file.buffer);
    const result = await video.analyzeVideo({
      apiKey: AGNES_KEY,
      model: VISION_MODEL,
      filePath: tmp,
      question: req.body.question,
      frameCount: Math.min(12, Math.max(2, +req.body.frames || 6)),
    });
    res.json(result);
  } catch (e) {
    console.error(e.message);
    res.status(500).json({ error: e.message });
  } finally {
    if (tmp) fs.unlink(tmp, () => {});
  }
});

// Speech to text (Deepgram Nova-3)
app.post("/api/stt", upload.single("audio"), async (req, res) => {
  try {
    if (!req.file) return res.status(400).json({ error: "Audio file is required." });
    if (!DG_KEY) return res.status(503).json({ error: "Deepgram is not configured. Set DEEPGRAM_API_KEY in .env." });
    const r = await fetch("https://api.deepgram.com/v1/listen?model=nova-3&smart_format=true&language=en", {
      method: "POST",
      headers: { Authorization: `Token ${DG_KEY}`, "Content-Type": req.file?.mimetype || "audio/webm" },
      body: req.file.buffer
    });
    const j = await r.json();
    if (!r.ok) throw new Error(`Deepgram ${r.status}: ${j.err_msg || ""}`);
    res.json({ text: j.results?.channels?.[0]?.alternatives?.[0]?.transcript || "" });
  } catch (e) { console.error(e.message); res.status(500).json({ error: e.message }); }
});

// Text to speech (Deepgram Aura-2)
app.post("/api/tts", async (req, res) => {
  try {
    if (!DG_KEY) return res.status(503).json({ error: "Deepgram is not configured. Set DEEPGRAM_API_KEY in .env." });
    const r = await fetch(`https://api.deepgram.com/v1/speak?model=${encodeURIComponent(VOICE)}`, {
      method: "POST",
      headers: { Authorization: `Token ${DG_KEY}`, "Content-Type": "application/json" },
      body: JSON.stringify({ text: String(req.body.text || "").slice(0, 1900) })
    });
    if (!r.ok) throw new Error(`Deepgram ${r.status}: ${await r.text()}`);
    res.set("Content-Type", "audio/mpeg");
    res.send(Buffer.from(await r.arrayBuffer()));
  } catch (e) { console.error(e.message); res.status(500).json({ error: e.message }); }
});

process.on("SIGINT", async () => { await browserTool.close().catch(() => {}); process.exit(0); });

app.listen(PORT, () => {
  console.log(`\n  C.T.E.C.H. online  →  http://localhost:${PORT}\n`);
  if (!AGNES_KEY || AGNES_KEY.startsWith("paste")) console.log("  ⚠ Add AGNES_API_KEY to .env");
  if (!DG_KEY || DG_KEY.startsWith("paste")) console.log("  ⚠ Add DEEPGRAM_API_KEY to .env");
  if (!browserTool.isAvailable()) console.log("  ⚠ Playwright not installed — browser_* tools disabled until `npm install && npx playwright install chromium`");
  if (IS_MAC) execFile("open", [`http://localhost:${PORT}`]);
  else if (process.platform === "win32") execFile("cmd.exe", ["/c", "start", "", `http://localhost:${PORT}`]);
});
